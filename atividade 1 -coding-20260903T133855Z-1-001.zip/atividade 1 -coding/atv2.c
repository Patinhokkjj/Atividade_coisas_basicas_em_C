#include <stdio.h>
#include <locale.h>
/*2. Ler o raio de um c�rculo e calcular �rea e per�metro.*/
int main(){
    setlocale(LC_ALL, "Portuguese");
    float pi, n1, a, p;
    printf("\nDigite um raio de um circulo: ");
    scanf("%f", &n1);
    pi = 3.14;
    a = ((n1 * n1) * pi);
    p = ((n1 * 2) * pi);
    printf("\n A ar�a do circulo � : %.2f\n O perimetro do circulo �: %.2f", a, p);
    return 0;
}