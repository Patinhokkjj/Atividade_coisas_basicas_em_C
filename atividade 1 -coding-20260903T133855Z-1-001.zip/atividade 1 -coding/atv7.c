#include <stdio.h>
#include <locale.h>
/*7. Ler a altura e a largura de um ret�ngulo e calcular sua �rea e per�metro.*/
int main(){
    setlocale(LC_ALL, "Portuguese");
    int n1, n2, a, p;
    printf("\nDigite a altura do seu ret�ngulo: ");
    scanf("%d", &n1);
    printf("\nDigite a largura do seu ret�ngulo: ");
    scanf("%d", &n2);
    a = (n1 * n2);
    p = (n1 * 2) + (n2 * 2);
    printf("\nAr�a do retangulo �: %d\nPerimetro do retangulo �: %d", a, p);
    return 0;
}