#include <stdio.h>
#include <locale.h>
/*3. Ler tr�s n�meros e exibir a m�dia aritm�tica. */
int main(){
    setlocale(LC_ALL, "Portuguese");
    int n1, n2, n3, media;
    printf("\nDigite o primeiro n�mero: ");
    scanf("%d", &n1);
    printf("\nDigite o segundo n�mero: ");
    scanf("%d", &n2);
    printf("\nDigite o terceiro n�mero: ");
    scanf("%d", &n3);
    media = ((n1 + n2 + n3) / 3);
    printf("\nA m�dia dos numeros �: %d", media);
    return 0;
}